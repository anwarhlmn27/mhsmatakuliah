/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package javalogin;

import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.JFrame;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.showMessageDialog;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author DELL
 */
public class menuNilai extends javax.swing.JPanel {

    
    public menuNilai() {
        initComponents();
        setBackground(new Color(0,0,0,0));
        
        tblNilai.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        tblNilai.getTableHeader().setOpaque(false);
        tblNilai.getTableHeader().setBackground(new Color(153, 153, 153));
        tblNilai.getTableHeader().setForeground(new Color(255,255,255));
        tblNilai.setRowHeight(30); 
        loadData();
        comboMhs();
        comboMatkul();
    }
    
    public final void loadData(){
        String SUrl, SUser, SPass;
        SUrl = "jdbc:MySQL://localhost:3306/java_db";
        SUser = "root";
        SPass = "";  
      try {
       Class.forName("com.mysql.cj.jdbc.Driver");
       Connection con = DriverManager.getConnection(SUrl, SUser, SPass);
       Statement st = con.createStatement();
            
       DefaultTableModel model = new DefaultTableModel(new String[]{"ID","Matakuliah", "Nama Mahasiswa","Nilai"}, 0);
      
       tblNilai.setModel(model);
       String sql = "SELECT * FROM nilai";
       
       java.sql.ResultSet rs = st.executeQuery(sql);
       String id, nmMk,nmMhs, nilai;
       while(rs.next()){      
           id = rs.getString("id_nilai");
           nmMk = rs.getString("nm_matkul");
           nmMhs = rs.getString("nama");
           nilai = rs.getString("nilai");
         
         model.addRow(new Object[]{id, nmMk,nmMhs, nilai});
       }
     }catch(Exception e){
            System.out.println("Error "+ e.getMessage());
     }  
    }
    
    private void comboMatkul(){
        String SUrl, SUser, SPass, query;
        SUrl = "jdbc:MySQL://localhost:3306/java_db";
        SUser = "root";
        SPass = "";  

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(SUrl, SUser, SPass);
            Statement st = con.createStatement();

            query = "SELECT * FROM matakuliah";
            ResultSet rs = st.executeQuery(query);
            while(rs.next()){
                
                cbMk.addItem(rs.getString("nm_matkul"));
            }

        } catch (Exception e) {
            System.out.println("Error "+ e.getMessage());
        }
    }
    
    private void comboMhs(){
        String SUrl, SUser, SPass, query;
        SUrl = "jdbc:MySQL://localhost:3306/java_db";
        SUser = "root";
        SPass = "";  

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(SUrl, SUser, SPass);
            Statement st = con.createStatement();

            query = "SELECT * FROM student";
            ResultSet rs = st.executeQuery(query);
            while(rs.next()){
                
                cbMhs.addItem(rs.getString("nama"));
            }

        } catch (Exception e) {
            System.out.println("Error "+ e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnNilai = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblNilai = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtNilai = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtCari = new javax.swing.JTextField();
        btnCari = new javax.swing.JButton();
        cbMk = new javax.swing.JComboBox<>();
        cbMhs = new javax.swing.JComboBox<>();
        btnCreate = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();

        setPreferredSize(new java.awt.Dimension(1046, 688));
        setLayout(new java.awt.CardLayout());

        pnNilai.setBackground(new java.awt.Color(255, 255, 255));
        pnNilai.setPreferredSize(new java.awt.Dimension(1055, 688));

        tblNilai.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "No", "Mata Kuliah", "Nama", "Nilai"
            }
        ));
        tblNilai.setFocusable(false);
        tblNilai.setRowHeight(25);
        tblNilai.setSelectionBackground(new java.awt.Color(215, 213, 213));
        tblNilai.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(tblNilai);

        jLabel1.setFont(new java.awt.Font("SansSerif", 1, 28)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 153, 153));
        jLabel1.setText("DATA NILAI MAHASISWA");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 102, 102));
        jLabel2.setText("Nama Matakuliah");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(102, 102, 102));
        jLabel3.setText("Nama Mahasiswa");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(102, 102, 102));
        jLabel4.setText("Nilai");

        txtNilai.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtNilai.setForeground(new java.awt.Color(102, 102, 102));

        jLabel5.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(153, 153, 153));
        jLabel5.setText("Tabel Nilai Mahasiswa");

        txtCari.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtCari.setForeground(new java.awt.Color(102, 102, 102));
        txtCari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCariActionPerformed(evt);
            }
        });

        btnCari.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnCari.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/cari.png"))); // NOI18N
        btnCari.setText("Cari");
        btnCari.setBorderPainted(false);
        btnCari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCariActionPerformed(evt);
            }
        });

        cbMk.setForeground(new java.awt.Color(102, 102, 102));
        cbMk.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-- pilih --" }));
        cbMk.setPreferredSize(new java.awt.Dimension(64, 26));

        cbMhs.setForeground(new java.awt.Color(102, 102, 102));
        cbMhs.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "-- pilih --" }));
        cbMhs.setPreferredSize(new java.awt.Dimension(64, 26));
        cbMhs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbMhsActionPerformed(evt);
            }
        });

        btnCreate.setBackground(new java.awt.Color(0, 204, 0));
        btnCreate.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnCreate.setText("Create");
        btnCreate.setPreferredSize(new java.awt.Dimension(90, 35));
        btnCreate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCreateActionPerformed(evt);
            }
        });

        btnUpdate.setBackground(new java.awt.Color(0, 153, 153));
        btnUpdate.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnUpdate.setText("Update");
        btnUpdate.setPreferredSize(new java.awt.Dimension(90, 35));
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });

        btnDelete.setBackground(new java.awt.Color(153, 0, 0));
        btnDelete.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnDelete.setForeground(new java.awt.Color(255, 255, 255));
        btnDelete.setText("Delete");
        btnDelete.setPreferredSize(new java.awt.Dimension(90, 35));
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        btnClear.setBackground(new java.awt.Color(204, 204, 204));
        btnClear.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnClear.setForeground(new java.awt.Color(51, 51, 51));
        btnClear.setText("Clear");
        btnClear.setPreferredSize(new java.awt.Dimension(90, 35));
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pnNilaiLayout = new javax.swing.GroupLayout(pnNilai);
        pnNilai.setLayout(pnNilaiLayout);
        pnNilaiLayout.setHorizontalGroup(
            pnNilaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnNilaiLayout.createSequentialGroup()
                .addContainerGap(747, Short.MAX_VALUE)
                .addComponent(txtCari, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnCari)
                .addContainerGap())
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(pnNilaiLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(pnNilaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnNilaiLayout.createSequentialGroup()
                        .addComponent(btnCreate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnNilaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel3)
                        .addComponent(jLabel2)
                        .addComponent(jLabel1)
                        .addComponent(jLabel4)
                        .addComponent(jLabel5)
                        .addComponent(txtNilai, javax.swing.GroupLayout.DEFAULT_SIZE, 400, Short.MAX_VALUE)
                        .addComponent(cbMhs, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cbMk, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(617, Short.MAX_VALUE))
        );
        pnNilaiLayout.setVerticalGroup(
            pnNilaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnNilaiLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel1)
                .addGap(33, 33, 33)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbMk, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(4, 4, 4)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbMhs, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtNilai, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pnNilaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCreate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnUpdate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnDelete, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnClear, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addGroup(pnNilaiLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCari, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCari))
                .addGap(4, 4, 4)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(42, Short.MAX_VALUE))
        );

        add(pnNilai, "card2");
    }// </editor-fold>//GEN-END:initComponents

    private void txtCariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCariActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCariActionPerformed

    private void cbMhsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbMhsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbMhsActionPerformed

    private void btnCreateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCreateActionPerformed
        String Mk, nmStudent, nilai, query;
        String SUrl, SUser, SPass;
        SUrl = "jdbc:MySQL://localhost:3306/java_db";
        SUser = "root";
        SPass = "";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(SUrl, SUser, SPass);
            Statement st = con.createStatement();
            if(cbMk.getSelectedIndex()==0){
                JOptionPane.showMessageDialog(null, "Mata Kuliah harus di isi", "Alert",JOptionPane.WARNING_MESSAGE );
            }else if(cbMhs.getSelectedIndex()==0){
                JOptionPane.showMessageDialog(null, "Nama Mahasiswa harus di isi", "Alert",JOptionPane.WARNING_MESSAGE );
            }else if("".equals(txtNilai.getText())){
                JOptionPane.showMessageDialog(new JFrame(), "Nilai harus di isi", "Alert",JOptionPane.WARNING_MESSAGE );
            }else{
            Mk = cbMk.getSelectedItem().toString();
            nmStudent = cbMhs.getSelectedItem().toString();
            nilai = txtNilai.getText();
          
            query = "INSERT INTO nilai(nm_matkul,nama, nilai)" + "VALUES('"+Mk+"', '"+nmStudent+"', '"+nilai+"')";
            st.execute(query);
            cbMk.setSelectedIndex(0);
            cbMhs.setSelectedIndex(0);
            txtNilai.setText("");
            showMessageDialog(null,"New Student has been Created");
            loadData();
            con.close();
            
            }
        } catch (Exception e) {
            System.out.println("Error! " + e.getMessage());
        }
    }//GEN-LAST:event_btnCreateActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
        String ID;
        int notFound = 0;
        String mk, nm, nilai;
        String SUrl, SUser, SPass;
        SUrl = "jdbc:MySQL://localhost:3306/java_db";
        SUser = "root";
        SPass = "";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(SUrl, SUser, SPass);
            Statement st = con.createStatement();
            
            ID = txtCari.getText();
            if("".equals(ID)){
              JOptionPane.showMessageDialog(new JFrame(), "ID is require", "Dialog",
                                     JOptionPane.ERROR_MESSAGE);
            }else {
               String sql = "SELECT * FROM nilai WHERE id_nilai="+ID;
               ResultSet rs = st.executeQuery(sql);
               while(rs.next()){
                 notFound = 1;
                 mk = cbMk.getSelectedItem().toString();
                 nm = cbMhs.getSelectedItem().toString();
                 nilai = txtNilai.getText();
                 String sql2 = "UPDATE nilai SET nm_matkul='"+mk+"', nama='"+nm+"', nilai='"+nilai+"'  WHERE id_nilai="+ID;
                 st.executeUpdate(sql2); 
                 cbMk.setSelectedIndex(0);
                 cbMhs.setSelectedIndex(0);
                 txtNilai.setText("");
                 showMessageDialog(null,"Student has been Updated");
                 loadData();
                 con.close();
               }
               if(notFound == 0){
                  JOptionPane.showMessageDialog(new JFrame(), "invalid ID", "Dialog",
                                     JOptionPane.ERROR_MESSAGE);
               }
            }
        }catch(Exception e){
            System.out.println("Error "+ e.getMessage());
            
        } 
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        String ID;
        String SUrl, SUser, SPass;
        SUrl = "jdbc:MySQL://localhost:3306/java_db";
        SUser = "root";
        SPass = "";
        int notFound = 0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(SUrl, SUser, SPass);
            Statement st = con.createStatement();
            
            ID = txtCari.getText();
            if("".equals(ID)){
              JOptionPane.showMessageDialog(new JFrame(), "ID is require", "Dialog",
                                     JOptionPane.ERROR_MESSAGE);
            }else {
               String sql = "SELECT * FROM nilai WHERE id_nilai="+ID;
               ResultSet rs = st.executeQuery(sql);
               while(rs.next()){
                 notFound = 1;
                 String sql2 = "DELETE FROM nilai WHERE id_nilai="+ID;
                 st.executeUpdate(sql2); 
                 cbMk.setSelectedIndex(0);
                 cbMhs.setSelectedIndex(0);
                 txtNilai.setText("");
                 loadData();
                 con.close();
                 showMessageDialog(null,"Nilai has been Deleted");
               }
               if(notFound == 0){
                  JOptionPane.showMessageDialog(new JFrame(), "invalid ID", "Dialog",
                                     JOptionPane.ERROR_MESSAGE);
               }
            }
        }catch(Exception e){
            System.out.println("Error "+ e.getMessage());
            
        }  
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
        cbMk.setSelectedIndex(0);
        cbMhs.setSelectedIndex(0);
        txtNilai.setText("");
    }//GEN-LAST:event_btnClearActionPerformed

    private void btnCariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCariActionPerformed
        String ID;
        String SUrl, SUser, SPass;
        SUrl = "jdbc:MySQL://localhost:3306/java_db";
        SUser = "root";
        SPass = "";
        int notFound = 0;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(SUrl, SUser, SPass);
            Statement st = con.createStatement();
            
            ID = txtCari.getText();
            if("".equals(ID)){
              JOptionPane.showMessageDialog(new JFrame(), "ID is require", "Dialog",
                                     JOptionPane.ERROR_MESSAGE);
            }else {
               String sql = "SELECT * FROM nilai WHERE id_nilai="+ID;
               ResultSet rs = st.executeQuery(sql);
               while(rs.next()){
                   cbMk.setSelectedItem(rs.getString("nm_matkul"));
                   cbMhs.setSelectedItem(rs.getString("nama"));                   
                   txtNilai.setText(rs.getString("nilai"));
                   notFound = 1;

                  con.close();
               }
               if(notFound == 0){
                  JOptionPane.showMessageDialog(new JFrame(), "invalid ID", "Dialog",
                                     JOptionPane.ERROR_MESSAGE);
               }
            }
        }catch(Exception e){
            System.out.println("Error "+ e.getMessage());
            
        }  
    }//GEN-LAST:event_btnCariActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCari;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnCreate;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JComboBox<String> cbMhs;
    private javax.swing.JComboBox<String> cbMk;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel pnNilai;
    private javax.swing.JTable tblNilai;
    private javax.swing.JTextField txtCari;
    private javax.swing.JTextField txtNilai;
    // End of variables declaration//GEN-END:variables
}
